[ Author ]
Alex

[ Things added/changed with this mod ]
- 2 giant zombies that provide cans of blood upon harvest
- Bloodstone Arrow mod
- Bloodstone Axe
- Bloodstone Bomb
- Bloodstone Bullet mod
- Bloodstone Charge
- Bloodstone ingot
- Bloodstone Knife
- Bloodstone Pick
- Bloodstone Pickaxe
- Bloodstone Shovel
- Bloodstone Tip mod
- Can of Blood
- Steel blocks now upgrade to Bloodstone blocks