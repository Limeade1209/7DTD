[ Author ]
Alex

[ Things added/changed with this mod ]
- 5 giant zombies to harvest material from (Radiated Skateboarder, Radiated Steve, Party Girl, Fat Cop, Vulture Dragon)
- Bloodstone Arrow mod
- Bloodstone Axe
- Bloodstone Bomb
- Bloodstone Bullet mod
- Bloodstone Charge
- Bloodstone Ingot
- Bloodstone Knife
- Bloodstone loot bags
- Bloodstone Pick
- Bloodstone Pickaxe
- Bloodstone Shovel
- Bloodstone Tip mod
- Bloodstone Vitamins
- Bloodstone Wire mod
- Can of Blood
- Steel blocks now upgrade to Bloodstone blocks
- Suspicious Koolaid